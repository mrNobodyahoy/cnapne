package br.edu.ifpr.irati.cnapne.sistema_gestao_cnapne;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemaGestaoCnapneApplicationTests {

	@Test
	void contextLoads() {
	}

}
