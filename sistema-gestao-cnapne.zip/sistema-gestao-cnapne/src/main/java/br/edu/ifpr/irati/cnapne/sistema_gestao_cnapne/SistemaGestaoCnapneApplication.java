package br.edu.ifpr.irati.cnapne.sistema_gestao_cnapne;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemaGestaoCnapneApplication {

	public static void main(String[] args) {
		SpringApplication.run(SistemaGestaoCnapneApplication.class, args);
	}

}
